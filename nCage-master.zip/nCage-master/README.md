# nCage
A Chrome extension which replaces all images on all pages to Nicolas Cage.

![Nicholas Cage](https://lh3.googleusercontent.com/9JhvxuStnEhLKRC-AyoSUkeMud32xXGffP29-OAifL3O_9cyOD0_OGE4nCo5bePOqZnYB1nE=w640-h400-e365)


## Link
* Chrome: https://chrome.google.com/webstore/detail/ncage/hnbmfljfohghaepamnfokgggaejlmfol?hl=en
